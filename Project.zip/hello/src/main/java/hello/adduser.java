package hello;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class adduser {
	String url = "jdbc:mysql://localhost:3306/test";
	String user = "root";
	String pwd = "12345678";
	String query = "INSERT INTO users VALUES(?,?)";
	public boolean add(String uname,String password) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection(url,user,pwd);
			PreparedStatement st = conn.prepareStatement(query);
			st.setString(1,uname);
			st.setString(2, password);
		    st.executeUpdate();
			return true;
		}catch(Exception e) {
			e.printStackTrace();
		}
		return false;
	}
}
