package hello;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class signUp extends HttpServlet{
	public void service(HttpServletRequest req , HttpServletResponse res) throws ServletException, IOException {
		String user = req.getParameter("user");
		String pwd = req.getParameter("pwd");
		adduser a = new adduser();
		LoginDao l=new LoginDao();
		if(l.checkUsername(user)) {
			req.setAttribute("taken", "yes");
			RequestDispatcher rd = req.getRequestDispatcher("/signupPage.jsp");
			rd.forward(req, res);
		}
		else if(a.add(user, pwd)) {
			HttpSession session = req.getSession();
			session.setAttribute("user", user);
			res.sendRedirect("welcome.jsp"); 
		}
	}

}
