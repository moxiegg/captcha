package hello;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;

import javax.imageio.ImageIO;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
public class textToimage extends HttpServlet{
	private static final long serialVersionUID = 1L;
	public void service(HttpServletRequest req,HttpServletResponse res) throws IOException, ServletException {
		HttpSession session = req.getSession();
		String cap = (String)session.getAttribute("cap");
		String temp="";
		for(int i=0;i<cap.length();i++) {
			temp+=cap.charAt(i)+" ";
		}
		res.setContentType("image/jpg");
		int l=140,b=50;
		Font fnt = new Font("Monotype Corsiva",Font.BOLD,30);
		BufferedImage biImage = new BufferedImage(l,b,BufferedImage.TYPE_INT_RGB);
		Graphics2D g2DImage = (Graphics2D) biImage.getGraphics();
		g2DImage.setFont(fnt);
		g2DImage.setColor(Color.RED);
		g2DImage.scale(1, 1);
		g2DImage.drawString(temp,10,35);
		g2DImage.setColor(Color.white);
		g2DImage.drawLine(0, b/2, l, b/2);
		OutputStream osImage = res.getOutputStream();
		ImageIO.write(biImage, "jpeg" , osImage);
		g2DImage.dispose();
		//session.invalidate();
	}
}