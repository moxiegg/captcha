package hello;
import java.io.IOException;
import java.lang.Math;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
public class captcha extends HttpServlet{
	public void service(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException{
		
		int min = 33 , max = 126;
		int range = max - min + 1;
		StringBuffer sb = new StringBuffer();
		for(int i=0;i<5;i++) {
			double r = Math.random();
			sb.append(((char)((int)(r*range)+min)));
		}
		String cap = new String(sb);
		HttpSession session = req.getSession();
		session.setAttribute("cap",cap);
		String r=req.getParameter("value");//"signupPage.jsp";
		System.out.println(r);
		res.sendRedirect(r);
	}
}
