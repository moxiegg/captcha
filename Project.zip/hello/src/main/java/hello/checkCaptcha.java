package hello;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class checkCaptcha extends HttpServlet{
	public void service(HttpServletRequest req,HttpServletResponse res) throws IOException, ServletException {
		HttpSession session=req.getSession();
		String cap1 = (String)session.getAttribute("cap");
		String cap2 =  req.getParameter("cap2");
		String target = req.getParameter("page");
		String r="";
		if(!(cap1.equals(cap2))) {
			req.setAttribute("valid","false");
			RequestDispatcher rd = req.getRequestDispatcher("/"+target);
			rd.forward(req, res);
		}else {
			if(target.equals("loginPage.jsp"))r="check-user";
			else if(target.equals("signupPage.jsp"))r="signUp";
			req.setAttribute("valid", true);
			RequestDispatcher rd = req.getRequestDispatcher(r);
			rd.forward(req, res);
		}
	}
}
