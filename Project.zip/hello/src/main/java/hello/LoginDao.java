package hello;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class LoginDao {
	String url = "jdbc:mysql://localhost:3306/test";
	String user = "root";
	String pwd = "12345678";
	String query = "SELECT * FROM users WHERE name=? AND pwd=?";
	public boolean check(String uname,String password) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection(url,user,pwd);
			PreparedStatement st = conn.prepareStatement(query);
			st.setString(1,uname);
			st.setString(2, password);
			ResultSet rs = st.executeQuery();
			if(rs.next())return true;
		}catch(Exception e) {
			e.printStackTrace();
		}
		return false;
	}
	public boolean checkUsername(String uname) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection(url,user,pwd);
			String query = "SELECT * FROM users WHERE name=?";
			PreparedStatement st = conn.prepareStatement(query);
			st.setString(1,uname);
			ResultSet rs = st.executeQuery();
			if(rs.next())return true;
		}catch(Exception e) {
			e.printStackTrace();
		}
		return false;
	}
}
